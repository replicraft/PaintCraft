| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 31.6 ± 1.9 |  |  |
| `raw` | 70.0 ± 13.9 | +121.5% | (2.2x slower) |
| `lz4` | 90.6 ± 10.3 | +186.6% | (2.9x slower) |
| `zstd1` | 198.4 ± 3.4 | +527.8% | (6.3x slower) |
| `zstd3` | 192.7 ± 1.2 | +509.8% | (6.1x slower) |
