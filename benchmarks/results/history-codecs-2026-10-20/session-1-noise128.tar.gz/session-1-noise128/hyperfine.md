| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 14.9 ± 0.9 |  |  |
| `raw` | 29.9 ± 0.6 | +100.0% | (2.0x slower) |
| `lz4` | 32.3 ± 0.7 | +115.8% | (2.2x slower) |
| `zstd1` | 33.5 ± 0.5 | +124.1% | (2.2x slower) |
| `zstd3` | 35.7 ± 3.8 | +138.9% | (2.4x slower) |
