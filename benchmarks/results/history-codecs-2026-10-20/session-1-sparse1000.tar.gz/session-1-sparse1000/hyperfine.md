| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 202.0 ± 29.5 |  |  |
| `raw` | 310.8 ± 30.0 | +53.8% | (1.5x slower) |
| `lz4` | 319.8 ± 14.6 | +58.3% | (1.6x slower) |
| `zstd1` | 334.6 ± 2.0 | +65.6% | (1.7x slower) |
| `zstd3` | 335.3 ± 2.7 | +66.0% | (1.7x slower) |
