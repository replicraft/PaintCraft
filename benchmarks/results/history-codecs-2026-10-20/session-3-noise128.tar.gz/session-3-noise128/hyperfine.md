| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 14.6 ± 0.5 |  |  |
| `raw` | 29.6 ± 0.8 | +102.5% | (2.0x slower) |
| `lz4` | 31.8 ± 0.5 | +117.9% | (2.2x slower) |
| `zstd1` | 35.3 ± 3.9 | +141.5% | (2.4x slower) |
| `zstd3` | 34.9 ± 1.1 | +139.0% | (2.4x slower) |
