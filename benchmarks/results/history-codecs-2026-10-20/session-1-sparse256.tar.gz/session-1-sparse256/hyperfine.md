| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 35.5 ± 4.0 |  |  |
| `raw` | 67.1 ± 2.8 | +89.4% | (1.9x slower) |
| `lz4` | 70.6 ± 3.9 | +99.1% | (2.0x slower) |
| `zstd1` | 86.7 ± 3.6 | +144.6% | (2.4x slower) |
| `zstd3` | 119.3 ± 96.4 | +236.5% | (3.4x slower) |
