| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 31.1 ± 1.0 |  |  |
| `raw` | 62.3 ± 2.5 | +100.6% | (2.0x slower) |
| `lz4` | 87.3 ± 2.0 | +181.0% | (2.8x slower) |
| `zstd1` | 196.7 ± 1.5 | +533.3% | (6.3x slower) |
| `zstd3` | 194.6 ± 6.9 | +526.6% | (6.3x slower) |
