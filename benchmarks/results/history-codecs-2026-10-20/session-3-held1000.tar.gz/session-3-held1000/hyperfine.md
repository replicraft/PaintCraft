| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 203.8 ± 22.4 |  |  |
| `raw` | 302.1 ± 18.4 | +48.2% | (1.5x slower) |
| `lz4` | 316.9 ± 10.5 | +55.5% | (1.6x slower) |
| `zstd1` | 355.2 ± 32.9 | +74.2% | (1.7x slower) |
| `zstd3` | 330.4 ± 5.4 | +62.1% | (1.6x slower) |
