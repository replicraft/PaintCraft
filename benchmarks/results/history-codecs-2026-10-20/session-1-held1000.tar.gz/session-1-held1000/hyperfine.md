| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 220.9 ± 66.1 |  |  |
| `raw` | 288.5 ± 4.5 | +30.6% | (1.3x slower) |
| `lz4` | 434.6 ± 491.5 | +96.8% | (2.0x slower) |
| `zstd1` | 456.7 ± 185.5 | +106.8% | (2.1x slower) |
| `zstd3` | 346.9 ± 26.8 | +57.1% | (1.6x slower) |
