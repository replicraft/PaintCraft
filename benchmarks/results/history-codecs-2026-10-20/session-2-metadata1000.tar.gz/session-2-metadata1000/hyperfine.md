| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `zstd3` | 58.8 ± 0.9 |  |  |
| `zstd1` | 63.3 ± 17.2 | +7.6% |  |
| `lz4` | 59.2 ± 1.6 | +0.6% |  |
| `raw` | 58.5 ± 0.6 | -0.5% |  |
| `shared` | 80.4 ± 3.6 | +36.7% | (1.4x slower) |
