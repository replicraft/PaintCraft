| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 41.4 ± 17.1 |  |  |
| `raw` | 122.1 ± 80.5 | +195.0% | (3.0x slower) |
| `lz4` | 73.1 ± 5.7 | +76.6% | (1.8x slower) |
| `zstd1` | 86.6 ± 3.2 | +109.1% | (2.1x slower) |
| `zstd3` | 154.8 ± 153.2 | +273.9% | (3.7x slower) |
