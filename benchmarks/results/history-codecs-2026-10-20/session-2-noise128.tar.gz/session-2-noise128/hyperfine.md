| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `zstd3` | 36.4 ± 3.6 |  |  |
| `zstd1` | 34.5 ± 2.3 | -5.2% |  |
| `lz4` | 32.3 ± 0.8 | -11.2% |  |
| `raw` | 30.3 ± 1.0 | -16.7% |  |
| `shared` | 15.0 ± 0.9 | -58.8% | (2.4x faster) |
