| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `zstd3` | 194.6 ± 7.7 |  |  |
| `zstd1` | 230.3 ± 48.9 | +18.4% |  |
| `lz4` | 138.7 ± 124.0 | -28.7% |  |
| `raw` | 63.2 ± 2.3 | -67.5% | (3.1x faster) |
| `shared` | 32.1 ± 1.8 | -83.5% | (6.1x faster) |
