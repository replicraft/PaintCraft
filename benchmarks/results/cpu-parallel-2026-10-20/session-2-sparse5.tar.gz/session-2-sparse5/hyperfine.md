| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tiles256-t4` | 124.3 ± 78.1 |  |  |
| `tiles64-t4` | 127.0 ± 4.1 | +2.2% |  |
| `bands256-t4` | 80.9 ± 6.0 | -34.9% | (1.5x faster) |
| `bands64-t4` | 70.1 ± 5.4 | -43.6% | (1.8x faster) |
| `bands64-t2` | 79.3 ± 9.3 | -36.2% | (1.6x faster) |
| `bands64-t1` | 110.7 ± 6.6 | -10.9% |  |
| `serial` | 111.9 ± 24.7 | -9.9% |  |
