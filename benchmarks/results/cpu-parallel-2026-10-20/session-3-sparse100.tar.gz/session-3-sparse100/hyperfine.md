| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `serial` | 234.7 ± 16.0 |  |  |
| `bands64-t1` | 234.5 ± 36.8 | -0.1% |  |
| `bands64-t2` | 135.6 ± 6.8 | -42.2% | (1.7x faster) |
| `bands64-t4` | 112.6 ± 53.5 | -52.0% | (2.1x faster) |
| `bands256-t4` | 90.5 ± 6.0 | -61.4% | (2.6x faster) |
| `tiles64-t4` | 224.2 ± 45.0 | -4.5% |  |
| `tiles256-t4` | 105.6 ± 16.9 | -55.0% | (2.2x faster) |
