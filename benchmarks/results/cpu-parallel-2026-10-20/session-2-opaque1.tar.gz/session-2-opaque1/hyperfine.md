| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tiles256-t4` | 144.7 ± 9.2 |  |  |
| `tiles64-t4` | 169.0 ± 19.8 | +16.8% |  |
| `bands256-t4` | 115.8 ± 25.2 | -20.0% |  |
| `bands64-t4` | 127.1 ± 8.0 | -12.2% |  |
| `bands64-t2` | 97.8 ± 12.9 | -32.4% | (1.5x faster) |
| `bands64-t1` | 89.1 ± 18.8 | -38.4% | (1.6x faster) |
| `serial` | 76.1 ± 15.0 | -47.4% | (1.9x faster) |
