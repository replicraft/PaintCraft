| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `serial` | 378.5 ± 20.4 |  |  |
| `bands64-t1` | 408.8 ± 134.5 | +8.0% |  |
| `bands64-t2` | 220.1 ± 29.6 | -41.9% | (1.7x faster) |
| `bands64-t4` | 133.4 ± 8.6 | -64.7% | (2.8x faster) |
| `bands256-t4` | 141.7 ± 31.2 | -62.6% | (2.7x faster) |
| `tiles64-t4` | 161.3 ± 38.6 | -57.4% | (2.3x faster) |
| `tiles256-t4` | 134.6 ± 10.3 | -64.4% | (2.8x faster) |
