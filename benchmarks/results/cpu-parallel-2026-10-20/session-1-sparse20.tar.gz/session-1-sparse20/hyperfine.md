| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `serial` | 180.9 ± 30.1 |  |  |
| `bands64-t1` | 170.9 ± 4.6 | -5.5% |  |
| `bands64-t2` | 128.6 ± 32.9 | -28.9% |  |
| `bands64-t4` | 90.0 ± 20.3 | -50.2% | (2.0x faster) |
| `bands256-t4` | 73.8 ± 11.0 | -59.2% | (2.5x faster) |
| `tiles64-t4` | 188.7 ± 60.9 | +4.3% |  |
| `tiles256-t4` | 81.0 ± 7.9 | -55.2% | (2.2x faster) |
