| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `serial` | 6.4 ± 0.6 |  |  |
| `bands64-t1` | 29.4 ± 11.0 | +359.7% | (4.6x slower) |
| `bands64-t2` | 25.2 ± 4.8 | +294.1% | (3.9x slower) |
| `bands64-t4` | 42.2 ± 16.6 | +559.4% | (6.6x slower) |
| `bands256-t4` | 40.2 ± 7.3 | +528.7% | (6.3x slower) |
| `tiles64-t4` | 43.2 ± 21.8 | +574.8% | (6.7x slower) |
| `tiles256-t4` | 37.9 ± 6.1 | +492.6% | (5.9x slower) |
