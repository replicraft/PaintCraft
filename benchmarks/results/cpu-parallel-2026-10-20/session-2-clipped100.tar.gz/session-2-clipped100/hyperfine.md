| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tiles256-t4` | 179.8 ± 38.4 |  |  |
| `tiles64-t4` | 232.4 ± 44.7 | +29.2% |  |
| `bands256-t4` | 137.8 ± 10.7 | -23.4% |  |
| `bands64-t4` | 129.2 ± 13.6 | -28.2% |  |
| `bands64-t2` | 115.0 ± 13.0 | -36.1% | (1.6x faster) |
| `bands64-t1` | 104.5 ± 4.9 | -41.9% | (1.7x faster) |
| `serial` | 90.5 ± 11.1 | -49.7% | (2.0x faster) |
