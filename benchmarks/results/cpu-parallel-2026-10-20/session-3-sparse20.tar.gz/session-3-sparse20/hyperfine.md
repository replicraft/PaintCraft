| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `serial` | 177.2 ± 26.4 |  |  |
| `bands64-t1` | 173.9 ± 2.5 | -1.8% |  |
| `bands64-t2` | 104.8 ± 5.1 | -40.8% | (1.7x faster) |
| `bands64-t4` | 70.8 ± 1.7 | -60.0% | (2.5x faster) |
| `bands256-t4` | 87.3 ± 23.5 | -50.7% | (2.0x faster) |
| `tiles64-t4` | 176.2 ± 9.4 | -0.5% |  |
| `tiles256-t4` | 96.5 ± 46.3 | -45.5% | (1.8x faster) |
