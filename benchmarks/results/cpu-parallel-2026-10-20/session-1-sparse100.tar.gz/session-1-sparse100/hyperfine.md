| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `serial` | 221.3 ± 9.5 |  |  |
| `bands64-t1` | 224.1 ± 16.1 | +1.3% |  |
| `bands64-t2` | 134.6 ± 3.8 | -39.2% | (1.6x faster) |
| `bands64-t4` | 92.0 ± 5.7 | -58.4% | (2.4x faster) |
| `bands256-t4` | 111.4 ± 37.6 | -49.7% | (2.0x faster) |
| `tiles64-t4` | 337.1 ± 188.5 | +52.3% | (1.5x slower) |
| `tiles256-t4` | 97.9 ± 6.2 | -55.7% | (2.3x faster) |
