| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tiles256-t4` | 99.1 ± 4.7 |  |  |
| `tiles64-t4` | 207.0 ± 14.7 | +108.9% | (2.1x slower) |
| `bands256-t4` | 95.3 ± 17.2 | -3.8% |  |
| `bands64-t4` | 93.0 ± 7.4 | -6.2% |  |
| `bands64-t2` | 141.4 ± 17.6 | +42.6% | (1.4x slower) |
| `bands64-t1` | 247.0 ± 54.1 | +149.2% | (2.5x slower) |
| `serial` | 227.0 ± 6.9 | +129.0% | (2.3x slower) |
