| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `serial` | 393.3 ± 31.0 |  |  |
| `bands64-t1` | 374.2 ± 10.9 | -4.8% |  |
| `bands64-t2` | 224.6 ± 37.8 | -42.9% | (1.8x faster) |
| `bands64-t4` | 130.8 ± 2.8 | -66.7% | (3.0x faster) |
| `bands256-t4` | 131.1 ± 2.7 | -66.7% | (3.0x faster) |
| `tiles64-t4` | 147.6 ± 5.5 | -62.5% | (2.7x faster) |
| `tiles256-t4` | 149.1 ± 33.6 | -62.1% | (2.6x faster) |
