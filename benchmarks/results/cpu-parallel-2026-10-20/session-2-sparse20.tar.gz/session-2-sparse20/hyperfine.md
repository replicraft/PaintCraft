| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tiles256-t4` | 76.7 ± 9.0 |  |  |
| `tiles64-t4` | 161.3 ± 3.6 | +110.3% | (2.1x slower) |
| `bands256-t4` | 76.0 ± 10.7 | -0.8% |  |
| `bands64-t4` | 74.8 ± 8.2 | -2.4% |  |
| `bands64-t2` | 104.3 ± 5.1 | +36.1% | (1.4x slower) |
| `bands64-t1` | 184.7 ± 32.6 | +141.0% | (2.4x slower) |
| `serial` | 164.7 ± 1.8 | +114.8% | (2.1x slower) |
