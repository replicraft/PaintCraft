| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tiles256-t4` | 165.1 ± 39.8 |  |  |
| `tiles64-t4` | 172.5 ± 25.5 | +4.5% |  |
| `bands256-t4` | 225.9 ± 111.8 | +36.9% | (1.4x slower) |
| `bands64-t4` | 167.0 ± 18.6 | +1.1% |  |
| `bands64-t2` | 278.4 ± 46.4 | +68.6% | (1.7x slower) |
| `bands64-t1` | 485.0 ± 118.2 | +193.8% | (2.9x slower) |
| `serial` | 480.8 ± 126.1 | +191.2% | (2.9x slower) |
