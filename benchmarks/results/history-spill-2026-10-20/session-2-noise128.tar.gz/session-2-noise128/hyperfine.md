| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `disk-lz4` | 200.6 ± 38.8 |  |  |
| `heap-lz4` | 39.4 ± 5.0 | -80.4% | (5.1x faster) |
| `disk` | 179.1 ± 3.0 | -10.8% |  |
| `heap` | 35.9 ± 0.7 | -82.1% | (5.6x faster) |
