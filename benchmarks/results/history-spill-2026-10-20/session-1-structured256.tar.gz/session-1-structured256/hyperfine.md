| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 68.2 ± 1.6 |  |  |
| `disk` | 350.2 ± 6.8 | +413.8% | (5.1x slower) |
| `heap-lz4` | 94.5 ± 1.6 | +38.6% | (1.4x slower) |
| `disk-lz4` | 147.8 ± 5.1 | +116.9% | (2.2x slower) |
