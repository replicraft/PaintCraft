| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `disk-lz4` | 470.4 ± 14.6 |  |  |
| `heap-lz4` | 333.4 ± 15.6 | -29.1% |  |
| `disk` | 499.3 ± 40.8 | +6.1% |  |
| `heap` | 316.9 ± 14.9 | -32.6% | (1.5x faster) |
