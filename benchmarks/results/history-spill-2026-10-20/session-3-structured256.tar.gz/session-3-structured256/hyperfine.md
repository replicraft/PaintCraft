| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 72.1 ± 3.7 |  |  |
| `disk` | 364.4 ± 21.3 | +405.6% | (5.1x slower) |
| `heap-lz4` | 98.4 ± 5.6 | +36.5% | (1.4x slower) |
| `disk-lz4` | 146.7 ± 5.9 | +103.6% | (2.0x slower) |
