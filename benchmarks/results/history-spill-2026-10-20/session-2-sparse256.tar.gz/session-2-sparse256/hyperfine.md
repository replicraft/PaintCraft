| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `disk-lz4` | 120.0 ± 9.6 |  |  |
| `heap-lz4` | 84.6 ± 6.2 | -29.5% |  |
| `disk` | 110.2 ± 6.2 | -8.2% |  |
| `heap` | 76.0 ± 4.9 | -36.7% | (1.6x faster) |
