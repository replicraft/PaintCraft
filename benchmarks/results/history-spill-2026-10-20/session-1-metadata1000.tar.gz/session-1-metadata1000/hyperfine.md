| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 69.6 ± 4.4 |  |  |
| `disk` | 74.5 ± 1.3 | +7.0% |  |
| `heap-lz4` | 68.7 ± 1.4 | -1.3% |  |
| `disk-lz4` | 73.9 ± 0.9 | +6.2% |  |
