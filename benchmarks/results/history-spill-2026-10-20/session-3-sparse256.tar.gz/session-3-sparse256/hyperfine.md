| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 79.1 ± 7.3 |  |  |
| `disk` | 111.6 ± 18.3 | +41.1% | (1.4x slower) |
| `heap-lz4` | 83.7 ± 30.2 | +5.9% |  |
| `disk-lz4` | 110.0 ± 6.1 | +39.1% | (1.4x slower) |
