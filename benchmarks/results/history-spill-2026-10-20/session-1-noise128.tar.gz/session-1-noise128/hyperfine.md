| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 35.5 ± 0.7 |  |  |
| `disk` | 178.0 ± 5.0 | +401.8% | (5.0x slower) |
| `heap-lz4` | 44.0 ± 1.8 | +24.1% |  |
| `disk-lz4` | 178.5 ± 3.5 | +403.2% | (5.0x slower) |
