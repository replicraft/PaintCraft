| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 70.2 ± 2.0 |  |  |
| `disk` | 1374.9 ± 337.0 | +1857.6% | (19.6x slower) |
| `heap-lz4` | 75.0 ± 2.9 | +6.7% |  |
| `disk-lz4` | 1299.7 ± 27.2 | +1750.5% | (18.5x slower) |
