| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 309.6 ± 5.9 |  |  |
| `disk` | 450.3 ± 18.6 | +45.5% | (1.5x slower) |
| `heap-lz4` | 358.2 ± 46.0 | +15.7% |  |
| `disk-lz4` | 466.7 ± 15.2 | +50.7% | (1.5x slower) |
