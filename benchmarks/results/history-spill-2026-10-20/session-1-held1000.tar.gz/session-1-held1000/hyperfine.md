| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 306.6 ± 9.5 |  |  |
| `disk` | 635.4 ± 655.9 | +107.3% | (2.1x slower) |
| `heap-lz4` | 336.6 ± 16.6 | +9.8% |  |
| `disk-lz4` | 471.5 ± 38.3 | +53.8% | (1.5x slower) |
