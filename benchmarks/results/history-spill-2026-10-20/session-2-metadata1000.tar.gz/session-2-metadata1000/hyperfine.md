| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `disk-lz4` | 80.7 ± 11.5 |  |  |
| `heap-lz4` | 69.4 ± 1.0 | -14.0% |  |
| `disk` | 77.9 ± 9.3 | -3.4% |  |
| `heap` | 69.7 ± 1.3 | -13.6% |  |
