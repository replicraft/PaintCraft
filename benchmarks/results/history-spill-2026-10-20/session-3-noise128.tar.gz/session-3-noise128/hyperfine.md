| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 38.2 ± 2.7 |  |  |
| `disk` | 213.2 ± 44.7 | +458.2% | (5.6x slower) |
| `heap-lz4` | 42.0 ± 4.2 | +10.0% |  |
| `disk-lz4` | 192.7 ± 14.7 | +404.5% | (5.0x slower) |
