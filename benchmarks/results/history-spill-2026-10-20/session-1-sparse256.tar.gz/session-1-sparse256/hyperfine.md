| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 72.8 ± 1.7 |  |  |
| `disk` | 105.6 ± 6.1 | +45.2% | (1.5x slower) |
| `heap-lz4` | 76.8 ± 4.7 | +5.6% |  |
| `disk-lz4` | 109.4 ± 7.9 | +50.3% | (1.5x slower) |
