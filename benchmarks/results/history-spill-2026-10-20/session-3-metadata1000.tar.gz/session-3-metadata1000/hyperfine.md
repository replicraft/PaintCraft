| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `heap` | 72.8 ± 4.9 |  |  |
| `disk` | 81.5 ± 6.6 | +11.9% |  |
| `heap-lz4` | 72.0 ± 4.6 | -1.1% |  |
| `disk-lz4` | 78.9 ± 8.0 | +8.4% |  |
