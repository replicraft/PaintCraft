| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `disk-lz4` | 146.4 ± 6.7 |  |  |
| `heap-lz4` | 95.7 ± 2.1 | -34.6% | (1.5x faster) |
| `disk` | 435.9 ± 155.2 | +197.7% | (3.0x slower) |
| `heap` | 100.1 ± 28.4 | -31.7% | (1.5x faster) |
