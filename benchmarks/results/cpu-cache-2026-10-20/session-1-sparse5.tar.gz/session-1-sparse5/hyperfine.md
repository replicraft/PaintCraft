| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 112.5 ± 6.7 |  |  |
| `tile64` | 165.8 ± 109.6 | +47.4% | (1.5x slower) |
| `tile128` | 87.6 ± 7.7 | -22.1% |  |
| `tile256` | 79.1 ± 11.8 | -29.7% |  |
