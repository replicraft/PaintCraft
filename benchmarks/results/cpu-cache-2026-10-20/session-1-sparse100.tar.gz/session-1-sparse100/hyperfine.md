| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 246.9 ± 31.7 |  |  |
| `tile64` | 195.2 ± 13.1 | -20.9% |  |
| `tile128` | 106.8 ± 21.3 | -56.8% | (2.3x faster) |
| `tile256` | 76.2 ± 17.1 | -69.1% | (3.2x faster) |
