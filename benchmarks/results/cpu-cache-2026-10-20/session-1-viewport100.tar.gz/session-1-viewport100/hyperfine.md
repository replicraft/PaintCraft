| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 165.6 ± 30.9 |  |  |
| `tile64` | 112.9 ± 9.3 | -31.8% | (1.5x faster) |
| `tile128` | 76.4 ± 13.0 | -53.9% | (2.2x faster) |
| `tile256` | 67.7 ± 17.4 | -59.1% | (2.4x faster) |
