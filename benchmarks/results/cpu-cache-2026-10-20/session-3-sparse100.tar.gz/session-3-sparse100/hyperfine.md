| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 225.7 ± 3.5 |  |  |
| `tile64` | 184.9 ± 30.2 | -18.1% |  |
| `tile128` | 91.4 ± 19.3 | -59.5% | (2.5x faster) |
| `tile256` | 63.2 ± 2.5 | -72.0% | (3.6x faster) |
