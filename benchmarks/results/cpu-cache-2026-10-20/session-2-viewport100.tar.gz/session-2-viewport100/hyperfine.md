| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tile256` | 61.1 ± 18.1 |  |  |
| `tile128` | 68.1 ± 4.2 | +11.5% |  |
| `tile64` | 108.7 ± 17.8 | +77.8% | (1.8x slower) |
| `full` | 137.5 ± 10.1 | +125.0% | (2.3x slower) |
