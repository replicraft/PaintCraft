| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 308.9 ± 7.2 |  |  |
| `tile64` | 164.6 ± 78.1 | -46.7% | (1.9x faster) |
| `tile128` | 114.1 ± 31.0 | -63.1% | (2.7x faster) |
| `tile256` | 97.5 ± 4.3 | -68.4% | (3.2x faster) |
