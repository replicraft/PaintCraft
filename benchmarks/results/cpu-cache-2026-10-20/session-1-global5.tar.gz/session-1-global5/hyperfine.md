| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 355.9 ± 57.5 |  |  |
| `tile64` | 174.3 ± 111.6 | -51.0% | (2.0x faster) |
| `tile128` | 115.6 ± 8.9 | -67.5% | (3.1x faster) |
| `tile256` | 106.9 ± 14.7 | -70.0% | (3.3x faster) |
