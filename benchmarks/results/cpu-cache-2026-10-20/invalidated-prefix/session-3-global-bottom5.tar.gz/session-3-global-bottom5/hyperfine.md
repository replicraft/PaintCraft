| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 308.3 ± 9.3 |  |  |
| `tile64` | 409.4 ± 31.0 | +32.8% | (1.3x slower) |
| `tile128` | 358.3 ± 30.0 | +16.2% |  |
| `tile256` | 346.4 ± 33.0 | +12.4% |  |
