| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tile256` | 332.5 ± 13.2 |  |  |
| `tile128` | 362.8 ± 51.1 | +9.1% |  |
| `tile64` | 477.1 ± 126.9 | +43.5% | (1.4x slower) |
| `full` | 311.1 ± 6.5 | -6.4% |  |
