| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 306.0 ± 4.8 |  |  |
| `tile64` | 404.7 ± 14.6 | +32.3% | (1.3x slower) |
| `tile128` | 347.5 ± 15.6 | +13.6% |  |
| `tile256` | 332.5 ± 8.1 | +8.7% |  |
