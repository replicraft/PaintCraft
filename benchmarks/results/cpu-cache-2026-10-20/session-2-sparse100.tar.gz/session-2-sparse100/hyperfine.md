| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tile256` | 170.8 ± 167.6 |  |  |
| `tile128` | 195.2 ± 158.1 | +14.3% |  |
| `tile64` | 199.0 ± 29.4 | +16.5% |  |
| `full` | 234.6 ± 15.0 | +37.4% | (1.4x slower) |
