| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 110.2 ± 2.2 |  |  |
| `tile64` | 132.8 ± 8.4 | +20.6% |  |
| `tile128` | 154.2 ± 134.9 | +39.9% | (1.4x slower) |
| `tile256` | 94.2 ± 48.1 | -14.5% |  |
