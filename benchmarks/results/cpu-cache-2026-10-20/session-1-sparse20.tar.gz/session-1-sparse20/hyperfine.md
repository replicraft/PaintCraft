| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 222.8 ± 78.5 |  |  |
| `tile64` | 127.6 ± 5.9 | -42.7% | (1.7x faster) |
| `tile128` | 73.4 ± 11.3 | -67.1% | (3.0x faster) |
| `tile256` | 50.4 ± 3.5 | -77.4% | (4.4x faster) |
