| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 114.6 ± 43.8 |  |  |
| `tile64` | 167.3 ± 12.6 | +45.9% | (1.5x slower) |
| `tile128` | 138.5 ± 9.1 | +20.8% |  |
| `tile256` | 129.4 ± 8.4 | +12.9% |  |
