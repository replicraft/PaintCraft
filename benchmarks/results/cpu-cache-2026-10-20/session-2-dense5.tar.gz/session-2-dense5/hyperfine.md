| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tile256` | 86.7 ± 36.1 |  |  |
| `tile128` | 80.3 ± 10.4 | -7.5% |  |
| `tile64` | 87.5 ± 2.2 | +0.8% |  |
| `full` | 429.2 ± 132.2 | +394.9% | (4.9x slower) |
