| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tile256` | 72.8 ± 9.2 |  |  |
| `tile128` | 80.5 ± 6.0 | +10.5% |  |
| `tile64` | 128.2 ± 11.1 | +76.1% | (1.8x slower) |
| `full` | 112.5 ± 4.9 | +54.5% | (1.5x slower) |
