| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 489.6 ± 62.1 |  |  |
| `tile64` | 104.1 ± 13.3 | -78.7% | (4.7x faster) |
| `tile128` | 85.5 ± 10.7 | -82.5% | (5.7x faster) |
| `tile256` | 90.2 ± 14.7 | -81.6% | (5.4x faster) |
