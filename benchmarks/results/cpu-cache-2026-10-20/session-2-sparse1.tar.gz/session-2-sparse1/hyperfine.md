| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tile256` | 224.5 ± 112.4 |  |  |
| `tile128` | 200.9 ± 99.3 | -10.5% |  |
| `tile64` | 192.8 ± 31.4 | -14.1% |  |
| `full` | 136.8 ± 71.2 | -39.1% | (1.6x faster) |
