| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 112.3 ± 9.2 |  |  |
| `tile64` | 186.3 ± 34.7 | +65.9% | (1.7x slower) |
| `tile128` | 163.4 ± 40.7 | +45.6% | (1.5x slower) |
| `tile256` | 129.3 ± 9.9 | +15.1% |  |
