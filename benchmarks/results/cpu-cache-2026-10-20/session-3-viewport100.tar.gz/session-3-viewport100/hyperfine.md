| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 138.2 ± 10.7 |  |  |
| `tile64` | 108.3 ± 17.2 | -21.6% |  |
| `tile128` | 67.1 ± 2.7 | -51.4% | (2.1x faster) |
| `tile256` | 58.0 ± 10.8 | -58.0% | (2.4x faster) |
