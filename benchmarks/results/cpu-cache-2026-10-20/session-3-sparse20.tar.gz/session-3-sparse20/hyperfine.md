| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 176.0 ± 4.6 |  |  |
| `tile64` | 127.5 ± 18.0 | -27.6% |  |
| `tile128` | 83.8 ± 50.1 | -52.4% | (2.1x faster) |
| `tile256` | 52.1 ± 6.3 | -70.4% | (3.4x faster) |
