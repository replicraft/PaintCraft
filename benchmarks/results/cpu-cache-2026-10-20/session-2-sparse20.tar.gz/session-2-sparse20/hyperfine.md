| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tile256` | 46.6 ± 1.8 |  |  |
| `tile128` | 76.1 ± 30.4 | +63.4% | (1.6x slower) |
| `tile64` | 137.4 ± 30.2 | +195.1% | (3.0x slower) |
| `full` | 191.2 ± 22.8 | +310.6% | (4.1x slower) |
