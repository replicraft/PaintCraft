| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `full` | 391.6 ± 4.2 |  |  |
| `tile64` | 83.9 ± 1.3 | -78.6% | (4.7x faster) |
| `tile128` | 74.8 ± 1.5 | -80.9% | (5.2x faster) |
| `tile256` | 72.1 ± 2.8 | -81.6% | (5.4x faster) |
