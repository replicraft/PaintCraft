| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `tile256` | 98.3 ± 4.0 |  |  |
| `tile128` | 111.4 ± 30.8 | +13.3% |  |
| `tile64` | 142.8 ± 22.6 | +45.2% | (1.5x slower) |
| `full` | 319.4 ± 24.6 | +224.9% | (3.2x slower) |
