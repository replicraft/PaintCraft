| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `cached` | 19.1 ± 1.0 |  |  |
| `baseline` | 25.9 ± 1.0 | +35.1% | (1.4x slower) |
