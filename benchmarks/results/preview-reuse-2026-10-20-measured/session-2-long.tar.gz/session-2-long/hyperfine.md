| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `cached` | 17.8 ± 0.6 |  |  |
| `baseline` | 43.2 ± 1.2 | +142.3% | (2.4x slower) |
