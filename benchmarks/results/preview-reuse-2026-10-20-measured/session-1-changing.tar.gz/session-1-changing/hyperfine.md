| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 29.6 ± 1.2 |  |  |
| `cached` | 29.7 ± 1.2 | +0.3% |  |
