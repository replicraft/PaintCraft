| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 44.5 ± 1.7 |  |  |
| `cached` | 18.3 ± 1.0 | -58.8% | (2.4x faster) |
