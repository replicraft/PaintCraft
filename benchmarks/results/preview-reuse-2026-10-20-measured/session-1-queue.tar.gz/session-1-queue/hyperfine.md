| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 90.4 ± 27.8 |  |  |
| `cached` | 26.0 ± 0.7 | -71.3% | (3.5x faster) |
