| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 44.6 ± 1.9 |  |  |
| `cached` | 18.7 ± 0.8 | -58.1% | (2.4x faster) |
