| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 86.0 ± 15.9 |  |  |
| `cached` | 25.8 ± 0.6 | -69.9% | (3.3x faster) |
