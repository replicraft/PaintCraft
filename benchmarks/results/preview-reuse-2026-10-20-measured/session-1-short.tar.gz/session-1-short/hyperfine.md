| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 25.3 ± 0.9 |  |  |
| `cached` | 19.1 ± 0.8 | -24.5% |  |
