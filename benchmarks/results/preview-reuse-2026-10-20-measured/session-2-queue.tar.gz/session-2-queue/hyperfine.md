| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `cached` | 27.6 ± 3.0 |  |  |
| `baseline` | 88.3 ± 13.5 | +220.5% | (3.2x slower) |
