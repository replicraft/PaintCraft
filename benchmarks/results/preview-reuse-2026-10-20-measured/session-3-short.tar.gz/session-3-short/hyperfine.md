| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 26.2 ± 0.9 |  |  |
| `cached` | 19.6 ± 0.8 | -25.5% |  |
