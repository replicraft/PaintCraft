| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `cached` | 33.2 ± 12.2 |  |  |
| `baseline` | 30.1 ± 1.3 | -9.4% |  |
