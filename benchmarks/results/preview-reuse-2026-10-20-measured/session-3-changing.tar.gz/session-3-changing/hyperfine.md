| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 31.0 ± 2.1 |  |  |
| `cached` | 29.6 ± 1.3 | -4.7% |  |
