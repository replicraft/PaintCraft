| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 23.2 ± 14.5 |  |  |
| `pack32` | 35.7 ± 7.6 | +53.9% | (1.5x slower) |
| `pack64` | 39.2 ± 16.3 | +69.0% | (1.7x slower) |
| `pack128` | 34.5 ± 4.4 | +48.5% | (1.5x slower) |
