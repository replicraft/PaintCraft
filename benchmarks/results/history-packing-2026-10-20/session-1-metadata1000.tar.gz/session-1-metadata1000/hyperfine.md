| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 81.2 ± 1.5 |  |  |
| `pack32` | 59.3 ± 1.2 | -27.0% |  |
| `pack64` | 66.3 ± 19.9 | -18.4% |  |
| `pack128` | 65.1 ± 9.6 | -19.8% |  |
