| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 32.7 ± 3.3 |  |  |
| `pack32` | 64.8 ± 3.7 | +98.3% | (2.0x slower) |
| `pack64` | 65.3 ± 1.3 | +99.9% | (2.0x slower) |
| `pack128` | 67.6 ± 1.8 | +107.1% | (2.1x slower) |
