| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `pack128` | 30.4 ± 1.2 |  |  |
| `pack64` | 30.7 ± 1.8 | +0.9% |  |
| `pack32` | 37.2 ± 20.2 | +22.2% |  |
| `shared` | 15.2 ± 0.9 | -50.0% | (2.0x faster) |
