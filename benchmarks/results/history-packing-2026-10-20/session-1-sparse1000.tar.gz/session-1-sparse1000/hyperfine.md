| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 190.3 ± 4.0 |  |  |
| `pack32` | 318.3 ± 92.8 | +67.2% | (1.7x slower) |
| `pack64` | 302.6 ± 28.4 | +59.0% | (1.6x slower) |
| `pack128` | 322.1 ± 44.1 | +69.2% | (1.7x slower) |
