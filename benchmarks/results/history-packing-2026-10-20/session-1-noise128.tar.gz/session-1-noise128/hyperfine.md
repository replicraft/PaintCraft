| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 14.6 ± 0.4 |  |  |
| `pack32` | 29.9 ± 0.8 | +105.3% | (2.1x slower) |
| `pack64` | 30.0 ± 0.7 | +106.3% | (2.1x slower) |
| `pack128` | 31.5 ± 2.7 | +116.4% | (2.2x slower) |
