| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 208.0 ± 23.4 |  |  |
| `pack32` | 287.0 ± 10.1 | +38.0% | (1.4x slower) |
| `pack64` | 300.0 ± 18.7 | +44.2% | (1.4x slower) |
| `pack128` | 296.2 ± 6.9 | +42.4% | (1.4x slower) |
