| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `pack128` | 60.7 ± 1.1 |  |  |
| `pack64` | 59.1 ± 1.6 | -2.7% |  |
| `pack32` | 58.9 ± 0.8 | -3.0% |  |
| `shared` | 82.1 ± 2.6 | +35.4% | (1.4x slower) |
