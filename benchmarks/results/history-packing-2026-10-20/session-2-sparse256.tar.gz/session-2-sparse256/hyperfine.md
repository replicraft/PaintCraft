| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `pack128` | 69.9 ± 5.7 |  |  |
| `pack64` | 66.5 ± 2.7 | -4.9% |  |
| `pack32` | 65.8 ± 5.3 | -5.9% |  |
| `shared` | 31.8 ± 1.7 | -54.6% | (2.2x faster) |
