| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `pack128` | 292.7 ± 3.5 |  |  |
| `pack64` | 295.8 ± 19.6 | +1.1% |  |
| `pack32` | 282.5 ± 3.2 | -3.5% |  |
| `shared` | 219.1 ± 53.5 | -25.1% |  |
