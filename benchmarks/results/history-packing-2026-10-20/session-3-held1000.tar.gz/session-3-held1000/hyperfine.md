| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 223.9 ± 65.7 |  |  |
| `pack32` | 285.2 ± 10.4 | +27.4% |  |
| `pack64` | 292.4 ± 14.6 | +30.6% | (1.3x slower) |
| `pack128` | 300.2 ± 19.2 | +34.1% | (1.3x slower) |
