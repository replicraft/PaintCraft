| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 205.2 ± 29.6 |  |  |
| `pack32` | 295.7 ± 19.1 | +44.1% | (1.4x slower) |
| `pack64` | 299.3 ± 17.4 | +45.9% | (1.5x slower) |
| `pack128` | 298.5 ± 12.2 | +45.5% | (1.5x slower) |
