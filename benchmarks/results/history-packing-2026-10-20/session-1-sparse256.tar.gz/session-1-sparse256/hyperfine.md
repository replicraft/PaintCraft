| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 37.7 ± 18.1 |  |  |
| `pack32` | 64.2 ± 4.8 | +70.1% | (1.7x slower) |
| `pack64` | 65.5 ± 0.8 | +73.7% | (1.7x slower) |
| `pack128` | 67.6 ± 1.4 | +79.3% | (1.8x slower) |
