| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `shared` | 112.2 ± 42.6 |  |  |
| `pack32` | 102.1 ± 44.5 | -8.9% |  |
| `pack64` | 60.1 ± 1.8 | -46.4% | (1.9x faster) |
| `pack128` | 65.3 ± 13.9 | -41.7% | (1.7x faster) |
