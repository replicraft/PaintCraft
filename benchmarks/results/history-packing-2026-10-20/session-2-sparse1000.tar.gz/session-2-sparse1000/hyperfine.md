| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `pack128` | 306.1 ± 27.1 |  |  |
| `pack64` | 375.4 ± 338.0 | +22.6% |  |
| `pack32` | 332.1 ± 75.6 | +8.5% |  |
| `shared` | 200.5 ± 7.7 | -34.5% | (1.5x faster) |
