| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `automatic` | 229.1 ± 6.0 |  |  |
| `explicit` | 538.0 ± 82.1 | +134.8% | (2.3x slower) |
