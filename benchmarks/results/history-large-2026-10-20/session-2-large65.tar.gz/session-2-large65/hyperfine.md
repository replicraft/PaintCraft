| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `explicit` | 278.2 ± 17.4 |  |  |
| `automatic` | 130.9 ± 4.4 | -52.9% | (2.1x faster) |
