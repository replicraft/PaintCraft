| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `automatic` | 164.2 ± 6.2 |  |  |
| `explicit` | 347.3 ± 8.3 | +111.6% | (2.1x slower) |
