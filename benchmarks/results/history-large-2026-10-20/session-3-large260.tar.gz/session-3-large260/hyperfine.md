| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `automatic` | 258.8 ± 54.4 |  |  |
| `explicit` | 538.3 ± 21.9 | +108.0% | (2.1x slower) |
