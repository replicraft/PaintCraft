| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `automatic` | 129.1 ± 5.3 |  |  |
| `explicit` | 271.8 ± 8.9 | +110.5% | (2.1x slower) |
