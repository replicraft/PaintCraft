| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `explicit` | 592.5 ± 137.2 |  |  |
| `automatic` | 241.6 ± 13.3 | -59.2% | (2.5x faster) |
