| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `automatic` | 180.7 ± 11.4 |  |  |
| `explicit` | 360.7 ± 13.2 | +99.6% | (2.0x slower) |
