| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `automatic` | 168.6 ± 24.3 |  |  |
| `explicit` | 325.1 ± 20.3 | +92.8% | (1.9x slower) |
