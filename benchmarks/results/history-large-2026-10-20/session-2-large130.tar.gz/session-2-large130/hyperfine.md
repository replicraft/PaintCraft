| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `explicit` | 372.8 ± 24.2 |  |  |
| `automatic` | 168.8 ± 8.1 | -54.7% | (2.2x faster) |
