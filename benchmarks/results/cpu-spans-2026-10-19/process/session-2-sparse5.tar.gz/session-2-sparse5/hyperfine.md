| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 53.3 ± 9.5 |  |  |
| `baseline` | 540.1 ± 32.7 | +913.2% | (10.1x slower) |
