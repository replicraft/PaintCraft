| Command | Mean Wall Time [s] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 1.222 ± 0.041 |  |  |
| `production` | 0.086 ± 0.010 | -92.9% | (14.1x faster) |
