| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 47.1 ± 20.4 |  |  |
| `baseline` | 245.6 ± 23.7 | +421.7% | (5.2x slower) |
