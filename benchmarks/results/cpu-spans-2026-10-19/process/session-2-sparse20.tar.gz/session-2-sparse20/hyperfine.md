| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 48.4 ± 10.4 |  |  |
| `baseline` | 594.2 ± 335.6 | +1128.3% | (12.3x slower) |
