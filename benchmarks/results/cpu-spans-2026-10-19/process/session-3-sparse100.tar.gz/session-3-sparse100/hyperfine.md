| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 688.5 ± 73.5 |  |  |
| `production` | 83.6 ± 12.1 | -87.9% | (8.2x faster) |
