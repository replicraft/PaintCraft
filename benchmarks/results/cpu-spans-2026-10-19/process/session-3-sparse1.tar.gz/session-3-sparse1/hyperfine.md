| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 239.1 ± 37.2 |  |  |
| `production` | 48.0 ± 10.3 | -79.9% | (5.0x faster) |
