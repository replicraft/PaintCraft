| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 80.8 ± 5.5 |  |  |
| `baseline` | 665.8 ± 31.1 | +724.5% | (8.2x slower) |
