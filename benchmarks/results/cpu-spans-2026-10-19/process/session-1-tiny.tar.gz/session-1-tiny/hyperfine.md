| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 86.0 ± 10.1 |  |  |
| `production` | 62.9 ± 0.7 | -26.9% |  |
