| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 149.8 ± 4.9 |  |  |
| `baseline` | 197.2 ± 6.8 | +31.7% | (1.3x slower) |
