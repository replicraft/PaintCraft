| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 513.5 ± 58.0 |  |  |
| `production` | 44.4 ± 1.0 | -91.4% | (11.6x faster) |
