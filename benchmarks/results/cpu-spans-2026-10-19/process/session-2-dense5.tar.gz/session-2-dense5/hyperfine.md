| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 749.1 ± 113.4 |  |  |
| `baseline` | 700.3 ± 30.9 | -6.5% |  |
