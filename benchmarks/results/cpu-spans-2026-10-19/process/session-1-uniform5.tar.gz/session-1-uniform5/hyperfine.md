| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 215.5 ± 47.1 |  |  |
| `production` | 145.8 ± 1.2 | -32.3% | (1.5x faster) |
