| Command | Mean Wall Time [s] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 1.257 ± 0.070 |  |  |
| `production` | 0.081 ± 0.005 | -93.5% | (15.5x faster) |
