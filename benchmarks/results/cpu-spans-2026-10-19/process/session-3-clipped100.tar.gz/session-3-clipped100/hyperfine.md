| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 100.0 ± 16.6 |  |  |
| `production` | 86.6 ± 7.6 | -13.4% |  |
