| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 300.2 ± 142.9 |  |  |
| `production` | 42.5 ± 1.8 | -85.9% | (7.1x faster) |
