| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 75.2 ± 5.5 |  |  |
| `baseline` | 1267.4 ± 87.5 | +1586.3% | (16.9x slower) |
