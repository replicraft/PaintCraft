| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 702.0 ± 106.4 |  |  |
| `production` | 90.3 ± 23.1 | -87.1% | (7.8x faster) |
