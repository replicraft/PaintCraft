| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 540.8 ± 71.3 |  |  |
| `production` | 48.3 ± 8.0 | -91.1% | (11.2x faster) |
