| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 537.8 ± 24.2 |  |  |
| `production` | 50.2 ± 1.6 | -90.7% | (10.7x faster) |
