| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 753.4 ± 80.1 |  |  |
| `production` | 705.5 ± 24.9 | -6.4% |  |
