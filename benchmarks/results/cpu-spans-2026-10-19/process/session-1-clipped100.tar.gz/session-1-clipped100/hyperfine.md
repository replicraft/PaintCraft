| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 84.4 ± 7.4 |  |  |
| `production` | 91.4 ± 24.1 | +8.3% |  |
