| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 189.2 ± 6.6 |  |  |
| `production` | 156.5 ± 15.3 | -17.3% |  |
