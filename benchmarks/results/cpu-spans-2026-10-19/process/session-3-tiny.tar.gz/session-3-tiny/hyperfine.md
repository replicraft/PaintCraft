| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 79.5 ± 2.2 |  |  |
| `production` | 63.8 ± 1.6 | -19.8% |  |
