| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 526.1 ± 28.3 |  |  |
| `production` | 59.7 ± 5.9 | -88.6% | (8.8x faster) |
