| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 62.5 ± 0.7 |  |  |
| `baseline` | 77.8 ± 1.0 | +24.4% |  |
