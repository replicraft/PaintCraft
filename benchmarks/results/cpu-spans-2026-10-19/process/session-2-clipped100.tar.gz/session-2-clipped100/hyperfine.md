| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `production` | 127.8 ± 49.3 |  |  |
| `baseline` | 99.7 ± 14.1 | -22.0% |  |
