| Command | Mean Wall Time [ms] | Change | Factor |
|:---|---:|---:|:---|
| `baseline` | 706.1 ± 45.3 |  |  |
| `production` | 761.9 ± 49.1 | +7.9% |  |
